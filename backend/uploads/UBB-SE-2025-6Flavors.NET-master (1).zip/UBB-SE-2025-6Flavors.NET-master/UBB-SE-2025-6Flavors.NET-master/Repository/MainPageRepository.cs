﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.Design;
using System.Drawing;

using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Windows.ApplicationModel.Chat;
using WorkoutApp.Models;

namespace WorkoutApp.Repository
{
    public class MainPageRepository
    {
        private string loginString = @"Server=Dell\SQLEXPRESS;Database=ShopDB;Integrated Security=True;TrustServerCertificate=True";

        private SqlConnection connection;
        private List<IProduct> products;


        public List<IProduct> GetAllProducts()
        {
            List<IProduct> products = new List<IProduct>();
            using (SqlConnection connection = new SqlConnection(loginString))
            {
                connection.Open();
                SqlCommand selectCommand = new SqlCommand("SELECT * FROM Product WHERE IsActive = 1", connection);
                SqlDataReader reader = selectCommand.ExecuteReader();

                while (reader.Read())
                {
                    int category = reader.GetInt32(reader.GetOrdinal("CategoryID"));
                    IProduct product = null;

                    if (category == 1)
                    {
                        product = new ClothesProduct
                        (
                            id: reader.GetInt32(reader.GetOrdinal("ID")),
                            name: reader.GetString(reader.GetOrdinal("Name")),
                            price: reader.GetDouble(reader.GetOrdinal("Price")),
                            stock: reader.GetInt32(reader.GetOrdinal("Stock")),
                            categoryId: category,
                            color: reader.GetString(reader.GetOrdinal("Atributes")),
                            size: reader.GetString(reader.GetOrdinal("Size")),
                            description: reader.GetString(reader.GetOrdinal("Description")),
                            fileUrl: reader.GetString(reader.GetOrdinal("FileUrl")),
                            isActive: true
                        );

                    }

                    else if (category == 2)
                    {
                        product = new FoodProduct
                         (
                            id: reader.GetInt32(reader.GetOrdinal("ID")),
                            name: reader.GetString(reader.GetOrdinal("Name")),
                            price: reader.GetDouble(reader.GetOrdinal("Price")),
                            stock: reader.GetInt32(reader.GetOrdinal("Stock")),
                            categoryId: category,
                            size: reader.GetString(reader.GetOrdinal("Size")),
                            description: reader.GetString(reader.GetOrdinal("Description")),
                            fileUrl: reader.GetString(reader.GetOrdinal("FileUrl")),
                            isActive: true
                        );

                    }
                    else
                    {
                        product = new AccessoryProduct
                        (
                            id: reader.GetInt32(reader.GetOrdinal("ID")),
                            name: reader.GetString(reader.GetOrdinal("Name")),
                            price: reader.GetDouble(reader.GetOrdinal("Price")),
                            stock: reader.GetInt32(reader.GetOrdinal("Stock")),
                            categoryId: category,
                            description: reader.GetString(reader.GetOrdinal("Description")),
                            fileUrl: reader.GetString(reader.GetOrdinal("FileUrl")),
                            isActive: true
                        );
                    }

                    products.Add(product);
                }

                reader.Close();
            }

            return products;
        }



        public List<IProduct> SearchProducts(string searchTerm)
        {
            List<IProduct> products = new List<IProduct>();
            SqlConnection connection = new SqlConnection(loginString);
            connection.Open();

            SqlCommand selectCommand = new SqlCommand(
                "SELECT * FROM Product WHERE IsActive = 1 AND (Name LIKE @search OR Description LIKE @search)",
                connection);
            selectCommand.Parameters.AddWithValue("@search", "%" + searchTerm + "%");

            SqlDataReader reader = selectCommand.ExecuteReader();

            while (reader.Read())
            {
                int category = reader.GetInt32(reader.GetOrdinal("CategoryID"));
                IProduct product = null;

                if (category == 1)
                {
                    product = new ClothesProduct
                    (
                        id: reader.GetInt32(reader.GetOrdinal("ID")),
                        name: reader.GetString(reader.GetOrdinal("Name")),
                        price: reader.GetDouble(reader.GetOrdinal("Price")),
                        stock: reader.GetInt32(reader.GetOrdinal("Stock")),
                        categoryId: category,
                        color: reader.GetString(reader.GetOrdinal("Atributes")),
                        size: reader.GetString(reader.GetOrdinal("Size")),
                        description: reader.GetString(reader.GetOrdinal("Description")),
                        fileUrl: reader.GetString(reader.GetOrdinal("FileUrl")),
                        isActive: true
                    );

                }

                else if (category == 2)
                {
                    product = new FoodProduct
                     (
                        id: reader.GetInt32(reader.GetOrdinal("ID")),
                        name: reader.GetString(reader.GetOrdinal("Name")),
                        price: reader.GetDouble(reader.GetOrdinal("Price")),
                        stock: reader.GetInt32(reader.GetOrdinal("Stock")),
                        categoryId: category,
                        size: reader.GetString(reader.GetOrdinal("Size")),
                        description: reader.GetString(reader.GetOrdinal("Description")),
                        fileUrl: reader.GetString(reader.GetOrdinal("FileUrl")),
                        isActive: true
                    );

                }
                else
                {
                    product = new AccessoryProduct
                    (
                        id: reader.GetInt32(reader.GetOrdinal("ID")),
                        name: reader.GetString(reader.GetOrdinal("Name")),
                        price: reader.GetDouble(reader.GetOrdinal("Price")),
                        stock: reader.GetInt32(reader.GetOrdinal("Stock")),
                        categoryId: category,
                        description: reader.GetString(reader.GetOrdinal("Description")),
                        fileUrl: reader.GetString(reader.GetOrdinal("FileUrl")),
                        isActive: true
                    );
                }

                products.Add(product);
            }

            reader.Close();
            connection.Close();
            return products;
        }


    }
}
