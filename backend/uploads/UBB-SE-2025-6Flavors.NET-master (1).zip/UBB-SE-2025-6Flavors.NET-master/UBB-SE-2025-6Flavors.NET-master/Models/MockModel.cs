﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkoutApp.Models
{
    public class MockModel
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
