﻿using WorkoutApp.Repository;
using WorkoutApp.Models;
using System.Collections.Generic;

namespace WorkoutApp.Service
{
    public class MainPageService
    {
        private readonly MainPageRepository repository;

        public MainPageService()
        {
            repository = new MainPageRepository();
        }

        public List<IProduct> SearchProducts(string searchTerm)
        {
            return repository.SearchProducts(searchTerm);
        }
        public List<IProduct> GetAllProducts()
        {
            return repository.GetAllProducts();
        }

    }
}
